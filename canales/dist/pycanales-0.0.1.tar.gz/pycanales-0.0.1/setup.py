from setuptools import setup, find_packages

setup(name="pycanales",
      version="0.0.1",
      author="Edwin Charapaqui Sedano",
      author_email="<masterfisicapura@gmail.com>",
      description="Hidráulica de canales",
      packages=["pycanales"])
